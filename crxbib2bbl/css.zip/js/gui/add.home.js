window.tool['home'].innerHTML = `
<div class="modal-header">
<h3 class="modal-title">${window.name} ${window.version}
</h3>
<p style="font-size:10pt;">last update: 2023-05-20 </p>
</div>
<div class="modal-header">   
    <a class="fa fa-github fa-fw" style="font-size: 14px;"></a>
        <a href="https://github.com/iihciyekub/must-thesis-tools" target="_blank" style="font-size: 14px;">GitHub
            @Yongjian.Li</a>
        <span style="font-size: 14px;">&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;使用以下開源工具:</span>
        <a href="https://github.com/BYVoid/OpenCC" target="_blank" style="font-size: 14px;">OpenCC</a>
        <span style="font-size: 14px;">,</span>
        <a href="https://github.com/theajack/cnchar" target="_blank" style="font-size: 14px;">CNChar </a>
</div>
`


