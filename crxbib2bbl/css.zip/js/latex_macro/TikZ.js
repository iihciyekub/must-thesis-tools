window.marc5 = {
}

k="内置坐标.名称"
v = `
%\\node[<options>] (<name>) at (<coordinate>) {<text/content>};
\\node[] () at (0,0) {};
`;window.marc5[k] = v










k="内置坐标.名称"
v = `
axis description cs:1,1
xticklabel cs:0,0
yticklabel cs:0,0
zticklabel cs:0,0
xticklabel* cs:0,0
yticklabel* cs:0,0
zticklabel* cs:0,0
current bounding box
current path bounding box
current subpath start
current page
`;window.marc5[k] = v



k="tikzpicture 环境设置"
v = `
remember picture
overlay
scale=
width=
height=
even odd rule
`;window.marc5[k] = v




k="算子.基本参数"
v = `
name=
name path=
draw=
fill=
color=
text color=
opacity=
text opacity=
`;window.marc5[k] = v





k="线段.参数选项"
v = `
step=
ultra thin
very thin
thin
very thick
semithick
thick
very thick
ultra thick
line width=
line cap = round |rect | butt
line join = round | bevel | miter
shorten >=
shorten <=
rounded corners=
`;window.marc5[k] = v


k="变换操作.设置"
v = `
behind path
in front of path
shift only
shift={(0,0)}
xshift=
yshift=
scale=
xscale=
yscale=
scale around={2:(1,1)}
xslant=
yslant=
rotate=
rotate around={40:(1,1)}
rotate around x=
rotate around y=
rotate around z=
cm={1,1,0,1,(0,0)}
reset cm
transform canvas={scale=2}
transform canvas={rotate=180}
transform shape nonlinear
transform shape
sloped
`;window.marc5[k] = v


k="node 形状.参数"
v = `
circle
circle split
circle solidus
rectangle
diamond
trapezium
ellipse
semicircle
regular polygon
star
kite
shape aspect=1
shading=ball
shape border uses incircle
shape border rotate=45
`;window.marc5[k] = v



k="node 算子.参数选项"
v = `
text=
text opacity =
pos =
pin={[]45:txt}
pin distance=
pin edge={}
label=
label={[]45:txt}
label distance=
inner sep =
inner xsep =
inner ysep =
outer xsep=
outer ysep=
minimum height =
minimum width =
minimum size = 
shape border uses incircle
shape border rotate=45
align=right | flush left | lush center | justify
text width=0 cm
text height=0 pt
text depth=0.25ex
`;window.marc5[k] = v


k="node.算子.位置参数"
v = `
above
above=
below
below=
left
left=
right
right=
above left
above right
below left
below right
centered
on grid
node distance=
above=of $1
below=of $1
left=of $1
right=of $1
above left=of $1
below left=of $1
above right=of $1
below right=of $1
base left=of $1
base right=of $1
mid left=of $1
mid right=of $1
above=0 mm of $1
below=0 mm of $1
left=0 mm of $1
right=0 mm of $1
above left=0 mm of $1
below left=0 mm of $1
above right=0 mm of $1
below right=0 mm of $1
base left=0 mm of $1
base right=0 mm of $1
mid left=0 mm of $1
mid right=of $1
pos=0.1
anchor=
auto=left | right
swap
sloped
allow upside down
midway
near start
near end
very near start
very near end
at={(0,0)}
at start
at end
`;window.marc5[k] = v




k="anchor 锚点名称"
v = `
north
south
west
east
north.west
north.east
south.west
south.east
center
mid
base
45
45:4cm
`;window.marc5[k] = v


